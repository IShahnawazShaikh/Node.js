var obj=require('./moduleDemo');
var http=require('http');
http.createServer(function(req,res){
  res.writeHead(200,"successfull");
  // obj.hello(); 
  // obj.myFun();

  obj.fun1(); 
  obj.fun2();
  res.write("<h1>fun1 and fun2 is executed on the cmd</h1>")

  res.end("ended");  
}).listen('9001',function(){
	 console.log('server is running at 9001');
})