var hello=function(){
   console.log('in hello function');
};
var myFun=function(){
	console.log("in myFun function");
}
// module.exports=hello;
// module.exports=myFun;   /* only myFun is export*/


/* if we want to export both of them then use object*/ 
// module.exports={hello,myFun};  exporting both module

module.exports.fun1=hello;
module.exports.fun2=myFun;      /*if we want to assign different name for function*/


