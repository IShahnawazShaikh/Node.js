// var obj={
// 	square:function(num){
//         return num*num;
// 	},
//    cube:function(num){
//    	  return num*num*num;
//    }
// }
// module.exports=obj;

exports=module.exports={
	square:function(num){
        return num*num;
	},
   cube:function(num){
   	  return num*num*num;
   }
}