var obj=require('./moduleDemo2');
var http=require('http');
http.createServer(function(request,response){
	//response.writeHead(200,"successfull",{'content-type':'text/html'});
	response.writeHead(200,"successfull",{'content-type':'text/plain'});
    response.write('executed at the console');
    response.write("<h2>In H2 tag</h2>")
    console.log(obj.square(10));
    console.log(obj.cube(14));
    response.end();
}).listen(6562,function(){
	 console.log('server is running');
});